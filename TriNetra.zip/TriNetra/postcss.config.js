export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};
//postcss config